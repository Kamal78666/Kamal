# Overview

CLASS 8&14 BOOSTER is an AI-powered educational platform designed as a tutoring companion for students in classes 8-14. The application provides personalized learning experiences through an interactive chat interface where students can ask questions across various subjects and receive tailored responses based on their academic level and country-specific curriculum. The platform features user authentication, conversation management, favorites system, and comprehensive user profiles with customizable preferences.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client-side is built using **React with TypeScript** and follows a modern component-based architecture. The application uses **Wouter** for lightweight client-side routing and **TanStack Query** for efficient server state management and caching. The UI components are built with **Radix UI primitives** and styled using **Tailwind CSS** with the shadcn/ui design system, providing a consistent and accessible user interface.

The frontend implements a mobile-first responsive design with a bottom navigation pattern optimized for educational use. Key architectural decisions include:
- **Component-driven development** with reusable UI components in `/components/ui/`
- **Custom hooks** for authentication (`useAuth`) and application state management
- **Query-based data fetching** with automatic caching and background updates
- **Theme system** supporting light/dark modes with CSS custom properties

## Backend Architecture
The server-side follows a **Node.js/Express** REST API architecture with TypeScript. The application uses a **session-based authentication system** integrated with Replit's OpenID Connect for secure user management. The backend implements:

- **Express.js** as the web framework with middleware for logging, error handling, and request processing
- **Modular route handling** with separation of concerns between authentication, chat, and user management
- **Storage abstraction layer** (`IStorage` interface) providing a clean API for data operations
- **OpenAI integration** for AI-powered tutoring responses with curriculum-aware context

Key architectural patterns include:
- **Repository pattern** for data access through the storage interface
- **Middleware-based request processing** with authentication guards
- **Error handling** with consistent JSON responses and proper HTTP status codes
- **Development/production environment** handling with Vite integration for development

## Data Storage Solutions
The application uses **PostgreSQL** as the primary database with **Drizzle ORM** for type-safe database operations. The database schema supports:

- **User management** with profile customization (class level, country, language preferences)
- **Conversation tracking** with message history and subject categorization
- **Favorites system** for saving important questions and answers
- **Session storage** for authentication state management
- **Feedback collection** for continuous improvement

The database design emphasizes referential integrity with proper foreign key relationships and cascading deletes for data consistency.

## Authentication and Authorization
The application implements **Replit OpenID Connect (OIDC)** authentication using Passport.js strategy. The authentication system features:

- **Session-based authentication** with PostgreSQL session storage
- **Automatic user provisioning** with profile creation on first login
- **Protected routes** with middleware-based authorization checks
- **Secure session management** with configurable TTL and secure cookies

The authentication flow integrates seamlessly with the frontend through HTTP-only cookies and provides user context throughout the application.

# External Dependencies

## Core Technologies
- **Neon Database** (@neondatabase/serverless) - Serverless PostgreSQL database hosting
- **OpenAI API** - AI tutoring response generation using GPT-5 model
- **Replit Authentication** - OpenID Connect integration for user authentication

## UI and Styling
- **Radix UI** - Comprehensive collection of accessible UI primitives
- **Tailwind CSS** - Utility-first CSS framework for responsive design
- **Lucide React** - Icon library for consistent iconography
- **shadcn/ui** - Design system built on Radix UI and Tailwind CSS

## Development and Build Tools
- **Vite** - Fast build tool with hot module replacement for development
- **TypeScript** - Type safety across the entire application stack
- **ESBuild** - Fast JavaScript bundler for production builds
- **Drizzle Kit** - Database migration and schema management tools

## Runtime Dependencies
- **React Query** (@tanstack/react-query) - Server state management and caching
- **Wouter** - Lightweight client-side routing
- **Express.js** - Web application framework for the backend API
- **Passport.js** - Authentication middleware with OpenID Connect strategy