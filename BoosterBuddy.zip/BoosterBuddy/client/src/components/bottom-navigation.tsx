import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Home, MessageCircle, Heart, Clock, Settings } from "lucide-react";

export default function BottomNavigation() {
  const [location, setLocation] = useLocation();

  const navItems = [
    { id: "home", label: "Home", icon: Home, path: "/" },
    { id: "chat", label: "Chat", icon: MessageCircle, path: "/chat" },
    { id: "favorites", label: "Saved", icon: Heart, path: "/favorites" },
    { id: "history", label: "History", icon: Clock, path: "/history" },
    { id: "settings", label: "Settings", icon: Settings, path: "/settings" },
  ];

  const isActive = (path: string) => {
    if (path === "/" && location === "/") return true;
    if (path !== "/" && location.startsWith(path)) return true;
    return false;
  };

  return (
    <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-sm bottom-nav">
      <div className="flex items-center justify-around py-2">
        {navItems.map((item) => {
          const IconComponent = item.icon;
          const active = isActive(item.path);
          
          return (
            <Button
              key={item.id}
              variant="ghost"
              className={`nav-item flex flex-col items-center space-y-1 p-2 ${active ? "active" : ""}`}
              onClick={() => setLocation(item.path)}
              data-testid={`nav-${item.id}`}
            >
              <IconComponent size={20} />
              <span className="text-xs">{item.label}</span>
            </Button>
          );
        })}
      </div>
    </div>
  );
}
