import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { ThumbsUp, ThumbsDown, Heart, User, Bot } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Message } from "@shared/schema";

interface ChatMessageProps {
  message: Message;
}

export default function ChatMessage({ message }: ChatMessageProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [likeCount, setLikeCount] = useState(12);
  const [dislikeCount, setDislikeCount] = useState(2);
  const [isFavorited, setIsFavorited] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const favoriteMutation = useMutation({
    mutationFn: async () => {
      if (isFavorited) {
        // Remove from favorites - would need favorite ID
        // For now, just toggle state
      } else {
        // Add to favorites
        await apiRequest("POST", "/api/favorites", {
          messageId: message.id,
          subject: "General", // You'd get this from context
          question: message.role === "user" ? message.content : "AI Response",
          answer: message.role === "assistant" ? message.content : message.content,
        });
      }
    },
    onSuccess: () => {
      setIsFavorited(!isFavorited);
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
      toast({
        title: isFavorited ? "Removed from favorites" : "Added to favorites",
        description: isFavorited 
          ? "The message has been removed from your favorites." 
          : "The message has been saved to your favorites.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update favorites. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleFavoriteToggle = () => {
    favoriteMutation.mutate();
  };

  const isUser = message.role === "user";
  const isAI = message.role === "assistant";

  if (isUser) {
    return (
      <div className="flex items-start space-x-3 justify-end" data-testid={`user-message-${message.id}`}>
        <div className="flex-1 flex justify-end">
          <div className="max-w-xs chat-bubble-user rounded-lg p-4">
            <p className="text-sm text-secondary-foreground mb-1">Student</p>
            <p className="text-white">{message.content}</p>
          </div>
        </div>
        <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center flex-shrink-0">
          <User className="text-muted-foreground" size={16} />
        </div>
      </div>
    );
  }

  if (isAI) {
    return (
      <div className="flex items-start space-x-3" data-testid={`ai-message-${message.id}`}>
        <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
          <Bot className="text-primary-foreground" size={16} />
        </div>
        <div className="flex-1">
          <div className="bg-card border border-border rounded-lg p-4 chat-bubble-ai">
            <p className="text-sm text-muted-foreground mb-1">AI Tutor</p>
            <div className="text-foreground space-y-3">
              <div 
                className="prose prose-sm max-w-none dark:prose-invert"
                dangerouslySetInnerHTML={{ __html: message.content }}
              />

              {/* Expandable Section - placeholder */}
              {message.content.length > 200 && (
                <div className="border border-border rounded-lg">
                  <Button
                    variant="ghost"
                    className="w-full p-3 justify-between text-left hover:bg-muted/20 rounded-lg"
                    onClick={() => setIsExpanded(!isExpanded)}
                    data-testid={`expand-button-${message.id}`}
                  >
                    <span className="font-medium">Step-by-step Explanation</span>
                    <span className="text-muted-foreground">
                      {isExpanded ? "▲" : "▼"}
                    </span>
                  </Button>
                  {isExpanded && (
                    <div className="p-3 border-t border-border">
                      <p className="text-sm text-muted-foreground">
                        Detailed explanation would be shown here...
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Reaction & Feedback */}
              <div className="flex items-center justify-between pt-2">
                <div className="flex items-center space-x-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-muted-foreground hover:text-foreground p-1"
                    onClick={() => setLikeCount(prev => prev + 1)}
                    data-testid={`like-button-${message.id}`}
                  >
                    <ThumbsUp size={16} className="mr-1" />
                    <span className="text-sm">{likeCount}</span>
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-muted-foreground hover:text-foreground p-1"
                    onClick={() => setDislikeCount(prev => prev + 1)}
                    data-testid={`dislike-button-${message.id}`}
                  >
                    <ThumbsDown size={16} className="mr-1" />
                    <span className="text-sm">{dislikeCount}</span>
                  </Button>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className={`p-1 ${isFavorited ? "text-red-500" : "text-accent hover:text-accent/80"}`}
                  onClick={handleFavoriteToggle}
                  disabled={favoriteMutation.isPending}
                  data-testid={`favorite-button-${message.id}`}
                >
                  <Heart size={16} className={`mr-1 ${isFavorited ? "fill-current" : ""}`} />
                  <span className="text-sm">Save</span>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
