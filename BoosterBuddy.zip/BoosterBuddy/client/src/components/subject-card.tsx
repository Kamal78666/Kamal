import { Button } from "@/components/ui/button";

interface Subject {
  id: string;
  name: string;
  icon: React.ComponentType<{ className?: string; size?: number }>;
  classes: number[];
}

interface SubjectCardProps {
  subject: Subject;
  onClick: () => void;
}

export default function SubjectCard({ subject, onClick }: SubjectCardProps) {
  const IconComponent = subject.icon;
  
  return (
    <Button
      variant="ghost"
      className="bg-card border border-border rounded-xl p-4 h-auto flex-col items-start hover:bg-card/80 transition-colors"
      onClick={onClick}
      data-testid={`subject-card-${subject.id}`}
    >
      <div className={`w-12 h-12 subject-gradient-${subject.id} rounded-xl flex items-center justify-center mb-3`}>
        <IconComponent className="text-white" size={24} />
      </div>
      <h3 className="font-semibold text-foreground text-left">{subject.name}</h3>
    </Button>
  );
}
