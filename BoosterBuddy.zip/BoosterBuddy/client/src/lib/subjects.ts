import {
  Calculator,
  TestTube,
  Landmark,
  Globe,
  Book,
  Palette,
  Music,
  Laptop,
  TrendingUp,
  Gavel,
  Users,
  Brain,
} from "lucide-react";

export interface Subject {
  id: string;
  name: string;
  icon: React.ComponentType<any>;
  classes: number[];
}

export const subjects: Subject[] = [
  {
    id: "math",
    name: "Mathematics",
    icon: Calculator,
    classes: [8, 9, 10, 11, 12, 13, 14],
  },
  {
    id: "science",
    name: "Science",
    icon: TestTube,
    classes: [8, 9, 10, 11, 12],
  },
  {
    id: "history",
    name: "History",
    icon: Landmark,
    classes: [8, 9, 10, 11, 12, 13, 14],
  },
  {
    id: "geography",
    name: "Geography",
    icon: Globe,
    classes: [8, 9, 10, 11, 12],
  },
  {
    id: "literature",
    name: "Literature",
    icon: Book,
    classes: [8, 9, 10, 11, 12, 13, 14],
  },
  {
    id: "art",
    name: "Art",
    icon: Palette,
    classes: [8, 9, 10, 11, 12],
  },
  {
    id: "music",
    name: "Music",
    icon: Music,
    classes: [8, 9, 10, 11, 12],
  },
  {
    id: "computer",
    name: "Computer Science",
    icon: Laptop,
    classes: [9, 10, 11, 12, 13, 14],
  },
  {
    id: "economics",
    name: "Economics",
    icon: TrendingUp,
    classes: [11, 12, 13, 14],
  },
  {
    id: "political",
    name: "Political Science",
    icon: Gavel,
    classes: [11, 12, 13, 14],
  },
  {
    id: "sociology",
    name: "Sociology",
    icon: Users,
    classes: [11, 12, 13, 14],
  },
  {
    id: "psychology",
    name: "Psychology",
    icon: Brain,
    classes: [11, 12, 13, 14],
  },
];
