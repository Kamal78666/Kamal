import { useEffect } from "react";
import { GraduationCap } from "lucide-react";

export default function Splash() {
  return (
    <div className="mobile-container">
      <div className="flex flex-col items-center justify-center min-h-screen p-8 text-center">
        <div className="mb-8">
          <div className="w-24 h-24 mx-auto mb-6 gradient-bg rounded-2xl flex items-center justify-center shadow-2xl">
            <GraduationCap className="text-3xl text-white" size={48} />
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-2" data-testid="app-title">
            CLASS 8&14 BOOSTER
          </h1>
          <p className="text-lg text-muted-foreground" data-testid="app-tagline">
            Your AI Study Buddy for Class 8 & 14
          </p>
        </div>
        
        <div className="loading-animation w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" data-testid="loading-spinner"></div>
        
        <p className="text-sm text-muted-foreground mt-4" data-testid="loading-text">
          Loading your study companion...
        </p>
      </div>
    </div>
  );
}
