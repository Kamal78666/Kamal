import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, User, GraduationCap, MessageCircle, Plus } from "lucide-react";
import SubjectCard from "@/components/subject-card";
import { subjects } from "@/lib/subjects";
import { useAuth } from "@/hooks/useAuth";

export default function Home() {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const { user } = useAuth();

  const filteredSubjects = subjects.filter(subject =>
    subject.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSubjectClick = (subject: string) => {
    setLocation(`/chat?subject=${encodeURIComponent(subject)}`);
  };

  const handleChatClick = () => {
    setLocation("/chat");
  };

  const handleClassSelection = () => {
    setLocation("/class-selection");
  };

  const handleSettings = () => {
    setLocation("/settings");
  };

  return (
    <div className="mobile-container">
      <div className="flex flex-col min-h-screen">
        {/* Header */}
        <div className="p-6 pb-4">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold text-foreground" data-testid="app-header">
              CLASS 8&14 BOOSTER
            </h1>
            <Button 
              variant="ghost"
              size="icon"
              className="w-10 h-10 bg-card rounded-full"
              onClick={handleSettings}
              data-testid="button-profile"
            >
              <User className="text-muted-foreground" size={20} />
            </Button>
          </div>
          
          <div className="relative mb-6">
            <Search className="absolute left-4 top-4 text-muted-foreground" size={20} />
            <Input 
              type="text" 
              placeholder="Search for subjects or countries" 
              className="pl-12 py-4 rounded-xl bg-input border-border"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              data-testid="input-search"
            />
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 px-6 pb-24">
          {/* Subject Grid */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            {filteredSubjects.map((subject) => (
              <SubjectCard
                key={subject.id}
                subject={subject}
                onClick={() => handleSubjectClick(subject.name)}
                data-testid={`card-subject-${subject.id}`}
              />
            ))}
          </div>

          {/* Quick Actions */}
          <div className="mt-6">
            <h2 className="text-lg font-semibold text-foreground mb-4" data-testid="quick-actions-title">
              Quick Actions
            </h2>
            <div className="space-y-3">
              <Button 
                variant="ghost"
                className="w-full bg-card border border-border rounded-xl p-4 h-auto justify-start hover:bg-card/80 transition-colors"
                onClick={handleClassSelection}
                data-testid="button-select-class"
              >
                <div className="flex items-center space-x-4 w-full">
                  <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                    <GraduationCap className="text-primary-foreground" size={20} />
                  </div>
                  <div className="flex-1 text-left">
                    <h3 className="font-medium text-foreground">Select Your Class</h3>
                    <p className="text-sm text-muted-foreground">
                      Currently: Class {user?.selectedClass || 8}
                    </p>
                  </div>
                  <div className="text-muted-foreground">→</div>
                </div>
              </Button>

              <Button 
                variant="ghost"
                className="w-full bg-card border border-border rounded-xl p-4 h-auto justify-start hover:bg-card/80 transition-colors"
                onClick={handleChatClick}
                data-testid="button-ask-tutor"
              >
                <div className="flex items-center space-x-4 w-full">
                  <div className="w-10 h-10 bg-secondary rounded-xl flex items-center justify-center">
                    <MessageCircle className="text-secondary-foreground" size={20} />
                  </div>
                  <div className="flex-1 text-left">
                    <h3 className="font-medium text-foreground">Ask AI Tutor</h3>
                    <p className="text-sm text-muted-foreground">Get instant help with any question</p>
                  </div>
                  <div className="text-muted-foreground">→</div>
                </div>
              </Button>
            </div>
          </div>
        </div>

        {/* Floating Action Button */}
        <Button 
          className="fixed bottom-20 right-6 w-14 h-14 bg-secondary rounded-full shadow-lg hover:bg-secondary/90 transition-colors"
          onClick={handleChatClick}
          data-testid="button-floating-chat"
        >
          <Plus className="text-secondary-foreground" size={24} />
        </Button>
      </div>
    </div>
  );
}
