import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { ArrowLeft } from "lucide-react";
import SubjectCard from "@/components/subject-card";
import { subjects } from "@/lib/subjects";
import { countries } from "@/lib/countries";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

const classes = [8, 9, 10, 11, 12, 13, 14];
const classLabels = ["All", "Class 8", "Class 9", "Class 10", "Class 11"];

export default function ClassSelection() {
  const [, setLocation] = useLocation();
  const [selectedClass, setSelectedClass] = useState<number | null>(null);
  const [selectedCountry, setSelectedCountry] = useState("India");
  const [selectedLanguage, setSelectedLanguage] = useState("English");
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updateProfileMutation = useMutation({
    mutationFn: async (updates: any) => {
      await apiRequest("PATCH", "/api/user/profile", updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Profile Updated",
        description: "Your preferences have been saved successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSavePreferences = () => {
    if (selectedClass) {
      updateProfileMutation.mutate({
        selectedClass,
        selectedCountry,
        language: selectedLanguage,
      });
    }
  };

  const filteredSubjects = subjects.filter(subject => {
    if (!selectedClass) return true;
    return subject.classes.includes(selectedClass);
  });

  return (
    <div className="mobile-container">
      <div className="flex flex-col min-h-screen">
        {/* Header */}
        <div className="p-6 pb-4">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="icon"
                className="w-10 h-10 bg-card rounded-full"
                onClick={() => setLocation("/")}
                data-testid="button-back"
              >
                <ArrowLeft className="text-muted-foreground" size={20} />
              </Button>
              <h1 className="text-xl font-bold text-foreground" data-testid="page-title">
                CLASS 8&14 BOOSTER
              </h1>
            </div>
            
            {/* Language Toggle */}
            <div className="flex items-center space-x-2">
              <span className="text-sm text-foreground">English</span>
              <Switch 
                checked={selectedLanguage === "Urdu"}
                onCheckedChange={(checked) => setSelectedLanguage(checked ? "Urdu" : "English")}
                data-testid="switch-language"
              />
              <span className="text-sm text-muted-foreground">Urdu</span>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 px-6 pb-24">
          <h2 className="text-2xl font-bold text-foreground mb-6" data-testid="section-title">
            Select your preferences
          </h2>
          
          {/* Country Selection */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-foreground mb-3">Country</h3>
            <div className="grid grid-cols-2 gap-2">
              {countries.map((country) => (
                <Button
                  key={country.code}
                  variant={selectedCountry === country.name ? "default" : "outline"}
                  className="text-sm"
                  onClick={() => setSelectedCountry(country.name)}
                  data-testid={`button-country-${country.code}`}
                >
                  {country.flag} {country.name}
                </Button>
              ))}
            </div>
          </div>
          
          {/* Class Selection Pills */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-foreground mb-3">Class</h3>
            <div className="flex space-x-2 mb-4 overflow-x-auto">
              <Button
                variant={selectedClass === null ? "default" : "outline"}
                className="px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap"
                onClick={() => setSelectedClass(null)}
                data-testid="button-class-all"
              >
                All
              </Button>
              {classes.map((classNum) => (
                <Button
                  key={classNum}
                  variant={selectedClass === classNum ? "default" : "outline"}
                  className="px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap"
                  onClick={() => setSelectedClass(classNum)}
                  data-testid={`button-class-${classNum}`}
                >
                  Class {classNum}
                </Button>
              ))}
            </div>
          </div>

          {/* Subject Cards Grid */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-foreground mb-3">
              Available Subjects
              {selectedClass && ` for Class ${selectedClass}`}
            </h3>
            <div className="grid grid-cols-2 gap-4">
              {filteredSubjects.map((subject) => (
                <div key={subject.id} className="bg-white rounded-xl p-6 shadow-sm">
                  <div className={`w-12 h-12 subject-gradient-${subject.id} rounded-xl flex items-center justify-center mb-4`}>
                    <subject.icon className="text-white" size={20} />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-1" data-testid={`subject-name-${subject.id}`}>
                    {subject.name}
                  </h3>
                  <p className="text-sm text-gray-600">
                    Classes {subject.classes.join(", ")}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Save Button */}
          {(selectedClass || selectedCountry !== user?.selectedCountry || selectedLanguage !== user?.language) && (
            <Button
              className="w-full bg-primary text-primary-foreground py-3 rounded-xl font-medium"
              onClick={handleSavePreferences}
              disabled={updateProfileMutation.isPending}
              data-testid="button-save-preferences"
            >
              {updateProfileMutation.isPending ? "Saving..." : "Save Preferences"}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
