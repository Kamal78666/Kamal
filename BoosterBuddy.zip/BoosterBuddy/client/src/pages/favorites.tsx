import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Star } from "lucide-react";
import { subjects } from "@/lib/subjects";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Favorite } from "@shared/schema";

const filterTabs = ["All", "Math", "Science", "History", "English", "Arts"];

export default function Favorites() {
  const [, setLocation] = useLocation();
  const [activeFilter, setActiveFilter] = useState("All");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: favorites = [], isLoading } = useQuery<Favorite[]>({
    queryKey: ["/api/favorites", activeFilter],
  });

  const deleteFavoriteMutation = useMutation({
    mutationFn: async (favoriteId: string) => {
      await apiRequest("DELETE", `/api/favorites/${favoriteId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
      toast({
        title: "Removed from favorites",
        description: "The item has been removed from your favorites.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to remove from favorites. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleRemoveFavorite = (favoriteId: string) => {
    deleteFavoriteMutation.mutate(favoriteId);
  };

  const getSubjectIcon = (subjectName: string) => {
    const subject = subjects.find(s => s.name.toLowerCase() === subjectName.toLowerCase());
    return subject?.icon || subjects[0].icon;
  };

  const getSubjectGradient = (subjectName: string) => {
    const subject = subjects.find(s => s.name.toLowerCase() === subjectName.toLowerCase());
    return subject?.id || "math";
  };

  return (
    <div className="mobile-container">
      <div className="flex flex-col min-h-screen">
        {/* Header */}
        <div className="p-6 pb-4">
          <div className="flex items-center space-x-4 mb-6">
            <Button
              variant="ghost"
              size="icon"
              className="w-10 h-10 bg-card rounded-full"
              onClick={() => setLocation("/")}
              data-testid="button-back"
            >
              <ArrowLeft className="text-muted-foreground" size={20} />
            </Button>
            <h1 className="text-xl font-bold text-foreground" data-testid="page-title">
              Favorites
            </h1>
          </div>
          
          {/* Filter Tabs */}
          <div className="flex space-x-1 bg-muted rounded-lg p-1 mb-6 overflow-x-auto">
            {filterTabs.map((filter) => (
              <Button
                key={filter}
                variant={activeFilter === filter ? "default" : "ghost"}
                className="flex-1 py-2 px-3 rounded-md text-sm font-medium whitespace-nowrap"
                onClick={() => setActiveFilter(filter)}
                data-testid={`filter-${filter.toLowerCase()}`}
              >
                {filter}
              </Button>
            ))}
          </div>
        </div>

        {/* Favorites List */}
        <div className="flex-1 px-6 pb-24 space-y-4" data-testid="favorites-list">
          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto"></div>
              <p className="text-muted-foreground mt-2">Loading favorites...</p>
            </div>
          ) : favorites.length === 0 ? (
            <div className="text-center py-8">
              <Star className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">No favorites yet</h3>
              <p className="text-muted-foreground">
                Save your favorite questions and answers from the chat to see them here.
              </p>
            </div>
          ) : (
            favorites.map((favorite: Favorite) => {
              const SubjectIcon = getSubjectIcon(favorite.subject);
              const gradientClass = getSubjectGradient(favorite.subject);
              
              return (
                <div key={favorite.id} className="bg-card border border-border rounded-xl p-4">
                  <div className="flex items-start space-x-3 mb-3">
                    <div className={`w-10 h-10 subject-gradient-${gradientClass} rounded-lg flex items-center justify-center flex-shrink-0`}>
                      <SubjectIcon className="text-white" size={20} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="font-semibold text-foreground" data-testid={`favorite-subject-${favorite.id}`}>
                          {favorite.subject}
                        </h3>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-yellow-500 hover:text-yellow-600"
                          onClick={() => handleRemoveFavorite(favorite.id)}
                          data-testid={`button-remove-favorite-${favorite.id}`}
                        >
                          <Star className="fill-current" size={20} />
                        </Button>
                      </div>
                      <h4 className="font-medium text-foreground mb-2" data-testid={`favorite-question-${favorite.id}`}>
                        {favorite.question}
                      </h4>
                      <p className="text-muted-foreground text-sm line-clamp-2" data-testid={`favorite-answer-${favorite.id}`}>
                        {favorite.answer.substring(0, 100)}...
                      </p>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
