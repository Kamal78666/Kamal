import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { 
  ArrowLeft, 
  Moon, 
  Globe, 
  Bell, 
  Info, 
  Shield, 
  FileText,
  LogOut,
  User
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Settings() {
  const [, setLocation] = useLocation();
  const [feedback, setFeedback] = useState("");
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updateProfileMutation = useMutation({
    mutationFn: async (updates: any) => {
      await apiRequest("PATCH", "/api/user/profile", updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Settings Updated",
        description: "Your preferences have been saved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update settings. Please try again.",
        variant: "destructive",
      });
    },
  });

  const feedbackMutation = useMutation({
    mutationFn: async (content: string) => {
      await apiRequest("POST", "/api/feedback", { content });
    },
    onSuccess: () => {
      setFeedback("");
      toast({
        title: "Feedback Sent",
        description: "Thank you for your feedback! We appreciate your input.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send feedback. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleThemeToggle = (checked: boolean) => {
    setIsDarkMode(checked);
    updateProfileMutation.mutate({ theme: checked ? "dark" : "light" });
    
    // Apply theme immediately
    document.documentElement.classList.toggle("dark", checked);
  };

  const handleNotificationToggle = (checked: boolean) => {
    setNotificationsEnabled(checked);
    // In a real app, you'd save this preference and configure push notifications
  };

  const handleLanguageChange = () => {
    setLocation("/class-selection");
  };

  const handleSendFeedback = () => {
    if (!feedback.trim()) return;
    feedbackMutation.mutate(feedback);
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  return (
    <div className="mobile-container">
      <div className="flex flex-col min-h-screen">
        {/* Header */}
        <div className="p-6 pb-4">
          <div className="flex items-center space-x-4 mb-6">
            <Button
              variant="ghost"
              size="icon"
              className="w-10 h-10 bg-card rounded-full"
              onClick={() => setLocation("/")}
              data-testid="button-back"
            >
              <ArrowLeft className="text-muted-foreground" size={20} />
            </Button>
            <h1 className="text-xl font-bold text-foreground" data-testid="page-title">
              Settings
            </h1>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 px-6 pb-24">
          {/* Profile Section */}
          <div className="bg-card border border-border rounded-xl p-6 mb-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center">
                  {user?.profileImageUrl ? (
                    <img 
                      src={user.profileImageUrl} 
                      alt="Profile" 
                      className="w-16 h-16 rounded-full object-cover"
                    />
                  ) : (
                    <User className="text-muted-foreground" size={32} />
                  )}
                </div>
                <div>
                  <h3 className="font-semibold text-foreground" data-testid="user-name">
                    {user?.firstName && user?.lastName 
                      ? `${user.firstName} ${user.lastName}`
                      : user?.email?.split('@')[0] || "Student"}
                  </h3>
                  <p className="text-muted-foreground">Student</p>
                </div>
              </div>
              <Button
                variant="destructive"
                size="sm"
                onClick={handleLogout}
                data-testid="button-logout"
              >
                <LogOut size={16} className="mr-2" />
                Logout
              </Button>
            </div>
          </div>

          {/* Appearance Section */}
          <div className="mb-6">
            <h2 className="text-lg font-semibold text-foreground mb-4" data-testid="appearance-section">
              APPEARANCE
            </h2>
            <div className="bg-card border border-border rounded-xl">
              <div className="p-4 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Moon className="text-muted-foreground" size={20} />
                  <span className="font-medium text-foreground">Theme</span>
                </div>
                <Switch
                  checked={isDarkMode}
                  onCheckedChange={handleThemeToggle}
                  data-testid="switch-theme"
                />
              </div>
            </div>
          </div>

          {/* General Section */}
          <div className="mb-6">
            <h2 className="text-lg font-semibold text-foreground mb-4" data-testid="general-section">
              GENERAL
            </h2>
            <div className="bg-card border border-border rounded-xl">
              <Button
                variant="ghost"
                className="w-full p-4 justify-between border-b border-border rounded-none rounded-t-xl"
                onClick={handleLanguageChange}
                data-testid="button-language"
              >
                <div className="flex items-center space-x-3">
                  <Globe className="text-muted-foreground" size={20} />
                  <span className="font-medium text-foreground">Language</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-muted-foreground">{user?.language || "English"}</span>
                  <div className="text-muted-foreground">→</div>
                </div>
              </Button>
              <div className="p-4 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Bell className="text-muted-foreground" size={20} />
                  <span className="font-medium text-foreground">Notifications</span>
                </div>
                <Switch
                  checked={notificationsEnabled}
                  onCheckedChange={handleNotificationToggle}
                  data-testid="switch-notifications"
                />
              </div>
            </div>
          </div>

          {/* Study Progress */}
          <div className="mb-6">
            <h2 className="text-lg font-semibold text-foreground mb-4" data-testid="progress-section">
              STUDY PROGRESS
            </h2>
            <div className="bg-card border border-border rounded-xl p-6">
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary" data-testid="questions-count">
                    {user?.questionsAsked || 0}
                  </div>
                  <div className="text-sm text-muted-foreground">Questions Asked</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-secondary" data-testid="study-streak">
                    {user?.studyStreak || 0}
                  </div>
                  <div className="text-sm text-muted-foreground">Day Streak</div>
                </div>
              </div>
              <div className="text-center">
                <p className="text-sm text-muted-foreground">
                  Keep going! You've asked {Math.min(user?.questionsAsked || 0, 15)} questions this week – great job 🚀
                </p>
              </div>
            </div>
          </div>

          {/* Feedback Section */}
          <div className="mb-6">
            <h2 className="text-lg font-semibold text-foreground mb-4" data-testid="feedback-section">
              FEEDBACK
            </h2>
            <div className="bg-card border border-border rounded-xl p-4">
              <Textarea
                placeholder="Share your thoughts..."
                className="bg-transparent border-none resize-none focus:outline-none"
                rows={3}
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
                data-testid="textarea-feedback"
              />
              <Button
                className="w-full bg-secondary text-secondary-foreground px-6 py-3 rounded-lg font-medium hover:bg-secondary/90 transition-colors mt-4"
                onClick={handleSendFeedback}
                disabled={!feedback.trim() || feedbackMutation.isPending}
                data-testid="button-send-feedback"
              >
                {feedbackMutation.isPending ? "Sending..." : "Send Feedback"}
              </Button>
            </div>
          </div>

          {/* About Section */}
          <div className="mb-6">
            <h2 className="text-lg font-semibold text-foreground mb-4" data-testid="about-section">
              ABOUT
            </h2>
            <div className="bg-card border border-border rounded-xl">
              <Button
                variant="ghost"
                className="w-full p-4 justify-between hover:bg-muted/20 rounded-xl"
                data-testid="button-about"
              >
                <div className="flex items-center space-x-3">
                  <Info className="text-muted-foreground" size={20} />
                  <span className="font-medium text-foreground">About CLASS 8&14 BOOSTER</span>
                </div>
                <div className="text-muted-foreground">→</div>
              </Button>
              <div className="border-t border-border">
                <Button
                  variant="ghost"
                  className="w-full p-4 justify-between hover:bg-muted/20 rounded-none"
                  data-testid="button-privacy"
                >
                  <div className="flex items-center space-x-3">
                    <Shield className="text-muted-foreground" size={20} />
                    <span className="font-medium text-foreground">Privacy Policy</span>
                  </div>
                  <div className="text-muted-foreground">→</div>
                </Button>
              </div>
              <div className="border-t border-border">
                <Button
                  variant="ghost"
                  className="w-full p-4 justify-between hover:bg-muted/20 rounded-b-xl"
                  data-testid="button-terms"
                >
                  <div className="flex items-center space-x-3">
                    <FileText className="text-muted-foreground" size={20} />
                    <span className="font-medium text-foreground">Terms of Service</span>
                  </div>
                  <div className="text-muted-foreground">→</div>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
