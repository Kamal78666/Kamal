import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Search, Trash2, Clock } from "lucide-react";
import { subjects } from "@/lib/subjects";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Conversation } from "@shared/schema";

export default function History() {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: conversations = [], isLoading } = useQuery<Conversation[]>({
    queryKey: ["/api/conversations"],
  });

  const { data: searchResults = [] } = useQuery<Conversation[]>({
    queryKey: ["/api/search/conversations", searchQuery],
    enabled: searchQuery.length > 0,
  });

  const deleteConversationMutation = useMutation({
    mutationFn: async (conversationId: string) => {
      await apiRequest("DELETE", `/api/conversations/${conversationId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      toast({
        title: "Conversation deleted",
        description: "The conversation has been removed from your history.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete conversation. Please try again.",
        variant: "destructive",
      });
    },
  });

  const clearAllMutation = useMutation({
    mutationFn: async () => {
      // Delete all conversations one by one
      await Promise.all(
        conversations.map((conv: Conversation) =>
          apiRequest("DELETE", `/api/conversations/${conv.id}`)
        )
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      toast({
        title: "History cleared",
        description: "All conversations have been removed from your history.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to clear history. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleDeleteConversation = (conversationId: string) => {
    deleteConversationMutation.mutate(conversationId);
  };

  const handleClearAll = () => {
    if (conversations.length === 0) return;
    
    const confirm = window.confirm("Are you sure you want to clear all your chat history? This action cannot be undone.");
    if (confirm) {
      clearAllMutation.mutate();
    }
  };

  const handleConversationClick = (conversationId: string) => {
    setLocation(`/chat/${conversationId}`);
  };

  const getSubjectIcon = (subjectName: string) => {
    const subject = subjects.find(s => s.name.toLowerCase() === subjectName.toLowerCase());
    return subject?.icon || subjects[0].icon;
  };

  const getSubjectGradient = (subjectName: string) => {
    const subject = subjects.find(s => s.name.toLowerCase() === subjectName.toLowerCase());
    return subject?.id || "math";
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === now.toDateString()) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (date.toDateString() === yesterday.toDateString()) {
      return "Yesterday";
    } else {
      return date.toLocaleDateString();
    }
  };

  const groupConversationsByDate = (conversations: Conversation[]) => {
    const groups: { [key: string]: Conversation[] } = {};
    
    conversations.forEach((conv) => {
      const date = new Date(conv.createdAt || '');
      const now = new Date();
      const yesterday = new Date(now);
      yesterday.setDate(yesterday.getDate() - 1);
      
      let groupKey;
      if (date.toDateString() === now.toDateString()) {
        groupKey = "Today";
      } else if (date.toDateString() === yesterday.toDateString()) {
        groupKey = "Yesterday";
      } else {
        groupKey = date.toLocaleDateString();
      }
      
      if (!groups[groupKey]) {
        groups[groupKey] = [];
      }
      groups[groupKey].push(conv);
    });
    
    return groups;
  };

  const displayConversations = searchQuery ? searchResults : conversations;
  const groupedConversations = groupConversationsByDate(displayConversations);

  return (
    <div className="mobile-container">
      <div className="flex flex-col min-h-screen">
        {/* Header */}
        <div className="p-6 pb-4">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="icon"
                className="w-10 h-10 bg-card rounded-full"
                onClick={() => setLocation("/")}
                data-testid="button-back"
              >
                <ArrowLeft className="text-muted-foreground" size={20} />
              </Button>
              <h1 className="text-xl font-bold text-foreground" data-testid="page-title">
                History
              </h1>
            </div>
            <Button
              variant="ghost"
              className="text-destructive hover:text-destructive/80 text-sm font-medium"
              onClick={handleClearAll}
              disabled={conversations.length === 0 || clearAllMutation.isPending}
              data-testid="button-clear-all"
            >
              {clearAllMutation.isPending ? "Clearing..." : "Clear All"}
            </Button>
          </div>
          
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-4 top-4 text-muted-foreground" size={20} />
            <Input
              type="text"
              placeholder="Search your questions..."
              className="pl-12 py-4 rounded-xl bg-input border-border"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              data-testid="input-search"
            />
          </div>
        </div>

        {/* History List */}
        <div className="flex-1 px-6 pb-24" data-testid="history-list">
          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto"></div>
              <p className="text-muted-foreground mt-2">Loading history...</p>
            </div>
          ) : Object.keys(groupedConversations).length === 0 ? (
            <div className="text-center py-8">
              <Clock className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">No conversations yet</h3>
              <p className="text-muted-foreground">
                Start chatting with the AI tutor to see your conversation history here.
              </p>
            </div>
          ) : (
            Object.entries(groupedConversations).map(([dateGroup, convs]) => (
              <div key={dateGroup} className="mb-6">
                <h2 className="text-lg font-semibold text-foreground mb-4" data-testid={`date-group-${dateGroup}`}>
                  {dateGroup}
                </h2>
                <div className="space-y-3">
                  {convs.map((conversation: Conversation) => {
                    const SubjectIcon = getSubjectIcon(conversation.subject);
                    const gradientClass = getSubjectGradient(conversation.subject);
                    
                    return (
                      <div 
                        key={conversation.id} 
                        className="bg-card border border-border rounded-xl p-4 cursor-pointer hover:bg-card/80 transition-colors"
                        onClick={() => handleConversationClick(conversation.id)}
                        data-testid={`conversation-${conversation.id}`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <div className={`w-6 h-6 subject-gradient-${gradientClass} rounded-md flex items-center justify-center`}>
                              <SubjectIcon className="text-white" size={12} />
                            </div>
                            <span className="text-sm font-medium text-foreground">
                              {conversation.subject}
                            </span>
                            <span className="text-xs text-muted-foreground">
                              {formatDate(conversation.createdAt?.toISOString() || new Date().toISOString())}
                            </span>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-muted-foreground hover:text-destructive"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteConversation(conversation.id);
                            }}
                            data-testid={`button-delete-${conversation.id}`}
                          >
                            <Trash2 size={16} />
                          </Button>
                        </div>
                        <h3 className="font-medium text-foreground mb-1">
                          {conversation.title || "Untitled Conversation"}
                        </h3>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
