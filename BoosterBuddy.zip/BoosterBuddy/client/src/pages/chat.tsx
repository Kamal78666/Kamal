import { useState, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Mic, Send } from "lucide-react";
import ChatMessage from "@/components/chat-message";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import type { Message } from "@shared/schema";

export default function Chat() {
  const [, setLocation] = useLocation();
  const params = useParams();
  const conversationId = params.conversationId;
  
  const [message, setMessage] = useState("");
  const [currentSubject, setCurrentSubject] = useState("");
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get subject from URL params if available
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const subject = urlParams.get('subject');
    if (subject) {
      setCurrentSubject(subject);
    }
  }, []);

  // Fetch conversation messages if conversationId exists
  const { data: messages = [], isLoading } = useQuery<Message[]>({
    queryKey: ["/api/conversations", conversationId, "messages"],
    enabled: !!conversationId,
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (data: { question: string; subject: string; conversationId?: string }) => {
      const response = await apiRequest("POST", "/api/chat/message", data);
      return response.json();
    },
    onSuccess: (data) => {
      setMessage("");
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      if (data.conversation?.id && !conversationId) {
        setLocation(`/chat/${data.conversation.id}`);
      }
      if (conversationId) {
        queryClient.invalidateQueries({ 
          queryKey: ["/api/conversations", conversationId, "messages"] 
        });
      }
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (!message.trim()) return;
    
    const subject = currentSubject || "General";
    sendMessageMutation.mutate({
      question: message,
      subject,
      conversationId,
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="mobile-container">
      <div className="flex flex-col min-h-screen">
        {/* Chat Header */}
        <div className="bg-card border-b border-border p-4">
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="icon"
              className="w-10 h-10 bg-muted rounded-full"
              onClick={() => setLocation("/")}
              data-testid="button-back-home"
            >
              <ArrowLeft className="text-muted-foreground" size={20} />
            </Button>
            <div className="flex-1">
              <h1 className="text-lg font-semibold text-foreground" data-testid="chat-title">
                {currentSubject || "Chat"}
              </h1>
              {user && (
                <p className="text-sm text-muted-foreground">
                  Class {user.selectedClass} • {user.selectedCountry}
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 p-4 space-y-6 overflow-y-auto" data-testid="chat-messages">
          {!conversationId && messages.length === 0 && (
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                <div className="text-primary-foreground text-sm">🤖</div>
              </div>
              <div className="flex-1">
                <div className="bg-card border border-border rounded-lg p-4 chat-bubble-ai">
                  <p className="text-sm text-muted-foreground mb-1">AI Tutor</p>
                  <p className="text-foreground">
                    Hi there! How can I help you today? Feel free to ask me any question about {currentSubject || "your studies"}.
                  </p>
                </div>
              </div>
            </div>
          )}

          {messages.map((msg: Message) => (
            <ChatMessage 
              key={msg.id} 
              message={msg}
              data-testid={`message-${msg.id}`}
            />
          ))}

          {sendMessageMutation.isPending && (
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                <div className="text-primary-foreground text-sm">🤖</div>
              </div>
              <div className="flex-1">
                <div className="bg-card border border-border rounded-lg p-4 chat-bubble-ai">
                  <p className="text-sm text-muted-foreground mb-1">AI Tutor</p>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0.1s" }}></div>
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                    <span className="text-muted-foreground text-sm ml-2">Thinking...</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Chat Input */}
        <div className="p-4 bg-card border-t border-border">
          <div className="flex items-center space-x-3">
            <div className="flex-1 relative">
              <Input
                type="text"
                placeholder="Ask a question..."
                className="pr-12 py-3 rounded-xl bg-input border-border"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                disabled={sendMessageMutation.isPending}
                data-testid="input-message"
              />
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
                data-testid="button-voice"
              >
                <Mic size={20} />
              </Button>
            </div>
            <Button
              className="w-12 h-12 bg-secondary rounded-full hover:bg-secondary/90"
              onClick={handleSendMessage}
              disabled={!message.trim() || sendMessageMutation.isPending}
              data-testid="button-send"
            >
              <Send className="text-secondary-foreground" size={20} />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
