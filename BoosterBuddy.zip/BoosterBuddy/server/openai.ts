import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface TutorResponse {
  answer: string;
  subject: string;
  difficulty: string;
  followUpQuestions?: string[];
}

export async function generateTutorResponse(
  question: string,
  subject: string,
  studentClass: number,
  country: string,
  language: string = 'English'
): Promise<TutorResponse> {
  try {
    const prompt = `You are an AI tutor for CLASS 8&14 BOOSTER, helping students from class ${studentClass} in ${country}.

Subject: ${subject}
Student Question: ${question}
Language: ${language}
Country Curriculum: ${country}

Rules:
- Match the student's class level (${studentClass})
- Explain step-by-step for Math/Science
- Use simple language for Class 8-10, detailed for Class 11-14
- Support curriculum from ${country}
- Use encouraging, friendly tone
- Provide examples relevant to ${country} context
- Format your response in Markdown with headings, bold text, lists
- End with "👍 Did this help you?"

Respond with JSON in this format:
{
  "answer": "Your detailed markdown answer here",
  "subject": "${subject}",
  "difficulty": "beginner/intermediate/advanced",
  "followUpQuestions": ["question1", "question2", "question3"]
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are an expert educational AI tutor specialized in multiple country curricula. Provide accurate, helpful responses in the requested language and format."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      answer: result.answer || "I'm sorry, I couldn't generate a proper response. Please try asking your question differently.",
      subject: result.subject || subject,
      difficulty: result.difficulty || "intermediate",
      followUpQuestions: result.followUpQuestions || []
    };
  } catch (error) {
    console.error("OpenAI API error:", error);
    
    // Handle specific OpenAI errors gracefully
    if (error.status === 429 || error.message?.includes('quota') || error.message?.includes('rate limit')) {
      return {
        answer: `**I'm temporarily experiencing high demand! 🤖**

Here's what I can help you with for **${subject}** while I get back up to speed:

## ${question}

I'd love to provide you with a detailed step-by-step explanation, but I'm currently at capacity. Here are some study tips:

### For ${subject} (Class ${studentClass}):
- Review your textbook chapter on this topic
- Practice similar problems from your workbook
- Ask your teacher during class for personalized help
- Check online educational resources like Khan Academy

### Study Tips:
1. **Break down the problem** into smaller parts
2. **Practice regularly** - a little each day is better than cramming
3. **Ask questions** when you don't understand something
4. **Form study groups** with classmates

I'll be back soon to give you the detailed explanations you deserve! 

👍 Did this help you?`,
        subject,
        difficulty: "intermediate",
        followUpQuestions: [
          "What specific part of this topic do you find most challenging?",
          "Have you tried any practice problems yet?",
          "Would you like me to suggest some study resources?"
        ]
      };
    }
    
    // For other errors, provide a generic helpful response
    return {
      answer: `I'm having trouble processing your question right now, but I don't want to leave you hanging! 

**Your question:** ${question}

**Subject:** ${subject} (Class ${studentClass})

While I work on getting back online, here are some immediate steps you can take:
1. Check your class notes for similar examples
2. Review the relevant chapter in your textbook  
3. Try looking up "${question}" in your study materials
4. Ask a classmate or teacher for help

I'll be back shortly to give you the detailed explanation you deserve!

👍 Did this help you?`,
      subject,
      difficulty: "intermediate", 
      followUpQuestions: ["What part of this topic confuses you most?", "Do you have your textbook handy?", "Have you seen similar problems before?"]
    };
  }
}

export async function generateConversationTitle(messages: string[]): Promise<string> {
  try {
    const firstFewMessages = messages.slice(0, 3).join('\n');
    
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "Generate a short, descriptive title for this educational conversation. Keep it under 6 words and focused on the main topic."
        },
        {
          role: "user",
          content: `Generate a title for this conversation:\n${firstFewMessages}`
        }
      ],
    });

    return response.choices[0].message.content?.trim() || "Study Session";
  } catch (error) {
    console.error("Failed to generate title:", error);
    return "Study Session";
  }
}
